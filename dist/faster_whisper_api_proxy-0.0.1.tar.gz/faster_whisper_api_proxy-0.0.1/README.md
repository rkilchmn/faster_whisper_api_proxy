# faster_whisper_api_proxy
a python module that is a drop in replacement for faster_whisper but calls a remote faster_whisper implementation via API
